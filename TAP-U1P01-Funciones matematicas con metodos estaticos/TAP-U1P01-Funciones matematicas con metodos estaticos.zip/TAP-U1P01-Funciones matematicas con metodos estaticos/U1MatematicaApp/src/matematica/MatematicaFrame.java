/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                         Aplicación visual 
:*        
:*  Archivo     : MatematicaFrame.java
:*  Autor       : Jesús Rafael Medina Dimas     19130547
:*  Fecha       : 19/09/2020
:*  Compilador  : Netbeans IDE 8.2
:*  Descripci�n : En esta clase se encuentran los elementos visuales de la aplicación.    
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  19/09/2020 Rafael       Agregar el prólogo del código
:*  28/09/2020 Rafael       Se agregan condiciones de excepciones en caso de errores
                            para el código, se quitó el acceso al valor de X si no es 
                            necesario, se codifico el botón de Acerca de y se cambió 
                            el aspecto de los elementos visuales. 
:*  29/09/2020 Rafael       Se agregó la forma de obtener el resultado para una formula general
:*  01/10/2020 Rafael       Se modificó la representación de un resultado negativo en la formula general
:*------------------------------------------------------------------------------------------*/
package matematica;

import javax.swing.JOptionPane;

public class MatematicaFrame extends javax.swing.JFrame {

    public MatematicaFrame() {
        
        initComponents();
        jlblValor_C.setVisible( false );
        jtxfValor_C.setVisible( false );
        jlblResultadoDos.setVisible( false );
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jcbOperacion = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jlblValor_N = new javax.swing.JLabel();
        jlblValor_X = new javax.swing.JLabel();
        jtxfValor_N = new javax.swing.JTextField();
        jtxfValor_X = new javax.swing.JTextField();
        jlblValor_C = new javax.swing.JLabel();
        jtxfValor_C = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jlblResultado = new javax.swing.JLabel();
        jlblResultadoDos = new javax.swing.JLabel();
        jbtnCalcular = new javax.swing.JButton();
        jbtnAcercaDe = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Operación:");

        jcbOperacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Factorial", "Permutaciones", "Combinaciones", "Formula general" }));
        jcbOperacion.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jcbOperacionItemStateChanged(evt);
            }
        });
        jcbOperacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbOperacionActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos"));
        jPanel1.setToolTipText("");

        jlblValor_N.setText("n =");

        jlblValor_X.setText("x =");

        jtxfValor_X.setEnabled(false);

        jlblValor_C.setText("c =");

        jtxfValor_C.setEnabled(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jlblValor_C)
                        .addGap(55, 55, 55)
                        .addComponent(jtxfValor_C, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblValor_N)
                            .addComponent(jlblValor_X))
                        .addGap(55, 55, 55)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtxfValor_X, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtxfValor_N, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblValor_N)
                    .addComponent(jtxfValor_N, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblValor_X, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxfValor_X, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblValor_C, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxfValor_C, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Resultado"));

        jlblResultado.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jlblResultadoDos.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlblResultadoDos, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jlblResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jlblResultadoDos, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        jbtnCalcular.setText("Calcular");
        jbtnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCalcularActionPerformed(evt);
            }
        });

        jbtnAcercaDe.setText("?");
        jbtnAcercaDe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAcercaDeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(170, 170, 170)
                .addComponent(jLabel1)
                .addGap(39, 39, 39)
                .addComponent(jcbOperacion, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jbtnCalcular)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jbtnAcercaDe, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcbOperacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addComponent(jbtnCalcular))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jbtnAcercaDe))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
//------------------------------------------------------------------------------
    private void jbtnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCalcularActionPerformed
//Se codifica el botón de calcular y se mandan mensajes de error en caso de haber uno. 

        int n = 0, x = 0, c = 0;
        String operacion = jcbOperacion.getSelectedItem().toString();
        
        try{
            n = Integer.parseInt ( jtxfValor_N.getText() );
        } catch ( NumberFormatException ex ){
            
            JOptionPane.showMessageDialog( this, 
                    "Valor de n debe ser un número entero", 
                    "error", 
                    JOptionPane.ERROR_MESSAGE );
            jtxfValor_N.requestFocus();
            return;
             
        }
        
        try {
            
            if (operacion.equals( "Permutaciones" ) || 
                    operacion.equals( "Combinaciones" ) || 
                    operacion.equals ("Formula general") ) {
                x = Integer.parseInt( jtxfValor_X.getText() );
                
            }
        } catch ( NumberFormatException ex ) {
            
            JOptionPane.showMessageDialog( this,
                    "Valor de x debe ser un número entero",
                    "error",
                    JOptionPane.ERROR_MESSAGE );
            jtxfValor_X.requestFocus();
            
        }
        
        try{
            if( operacion.equals ( "Formula general" ) ){
                c = Integer.parseInt ( jtxfValor_C.getText() );
            }
        } catch ( NumberFormatException ex ){
            
            JOptionPane.showMessageDialog( this, 
                    "Valor de c debe ser un número entero", 
                    "error", 
                    JOptionPane.ERROR_MESSAGE );
            jtxfValor_C.requestFocus();
            return;
             
        }
        
        if ( operacion.equals ( "Factorial" ) ){
            jlblResultado.setText ( Matematica.factorial ( n ) + "" );
            
        } else if ( operacion.equals ( "Permutaciones" ) ){
            jlblResultado.setText ( Matematica.permutaciones ( n, x ) + "" );
            
        } else if ( operacion.equals ( "Combinaciones" ) ){
            jlblResultado.setText ( Matematica.combinaciones ( n, x ) + "" );
        } else if ( operacion.equals ( "Formula general" ) ){
            double disc = ( Math.pow ( x, 2 ) ) - ( 4 * n * c );
            if (disc < 0) {
                jlblResultado.setText ( "X1 = " + Matematica.FGImaginario ( n, x, c, disc ) [0] ) ;
                jlblResultadoDos.setText ( "X2 = " + Matematica.FGImaginario ( n, x, c, disc ) [1] ) ;
            }else{
                jlblResultado.setText ( "X1 = " + Matematica.FGReal ( n, x, c, disc ) [0] ) ;
                jlblResultadoDos.setText ( "X2 = " + Matematica.FGReal ( n, x, c, disc ) [1] ) ;
            }
            
        } 
    }//GEN-LAST:event_jbtnCalcularActionPerformed
//------------------------------------------------------------------------------
    private void jcbOperacionItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jcbOperacionItemStateChanged
//Se deshabilita el valor de X cuando no es necesario, y se habilita cuando lo es.
        jlblValor_C.setVisible( false );
        jtxfValor_C.setVisible( false );
        jlblResultadoDos.setVisible( false );
        
        jlblValor_N.setText( "n = " );
        jlblValor_X.setText( "x = " );
        jlblResultado.setText( " " );
        jlblResultadoDos.setText( " " );
        
        jtxfValor_N.setText( "" );
        jtxfValor_X.setText( "" );
        jtxfValor_C.setText( "" );
        
        if ( jcbOperacion.getSelectedItem().toString ().equals ( "Factorial" ) ) {
            
            jlblValor_X.setEnabled ( false );
            jtxfValor_X.setEnabled ( false );
            
        } else if (jcbOperacion.getSelectedItem().toString ().equals ( "Formula general" ) ) {
            jlblValor_C.setVisible( true );
            jtxfValor_C.setVisible( true );
            jtxfValor_C.setEnabled( true );
            jlblResultadoDos.setVisible( true );
            jlblValor_X.setEnabled ( true );
            jtxfValor_X.setEnabled ( true );
            jlblValor_N.setText( "a =" );
            jlblValor_X.setText( "b = " );
            
        } else {
            jlblValor_X.setEnabled ( true );
            jtxfValor_X.setEnabled ( true );
        }
        
    }//GEN-LAST:event_jcbOperacionItemStateChanged
//------------------------------------------------------------------------------
    private void jbtnAcercaDeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAcercaDeActionPerformed
//Se imprime en un cuadro de dialogo la información del alumno

        JOptionPane.showMessageDialog ( 
                this, "TECNOLOGICO NACIONAL DE MEXICO \n" + 
                "Instituto tecnologico de la laguna \n" +
                "ISC \t Topicos Avanzados de Programación \n\n" +
                "MatematicaApp v1.0 \n\n" +
                "Desarrollado por: \n "+
                "Jesús Rafael Medina Dimas 19130547 \n\n"+
                "(C) Derechos reservados 2020" ,
                "Acerca de", 
                JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jbtnAcercaDeActionPerformed

    private void jcbOperacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbOperacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcbOperacionActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Motif".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MatematicaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MatematicaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MatematicaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MatematicaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MatematicaFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jbtnAcercaDe;
    private javax.swing.JButton jbtnCalcular;
    private javax.swing.JComboBox<String> jcbOperacion;
    private javax.swing.JLabel jlblResultado;
    private javax.swing.JLabel jlblResultadoDos;
    private javax.swing.JLabel jlblValor_C;
    private javax.swing.JLabel jlblValor_N;
    private javax.swing.JLabel jlblValor_X;
    private javax.swing.JTextField jtxfValor_C;
    private javax.swing.JTextField jtxfValor_N;
    private javax.swing.JTextField jtxfValor_X;
    // End of variables declaration//GEN-END:variables
}
