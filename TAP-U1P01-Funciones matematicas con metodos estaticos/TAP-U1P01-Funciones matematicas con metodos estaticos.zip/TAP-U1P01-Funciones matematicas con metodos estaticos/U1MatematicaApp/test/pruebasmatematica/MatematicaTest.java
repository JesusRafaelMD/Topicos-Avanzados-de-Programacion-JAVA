/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                       Clase de prueba para la aplicación principal
:*        
:*  Archivo     : MatematicaTest.java
:*  Autor       : Jesús Rafael Medina Dimas     19130547
:*  Fecha       : 25/09/2020
:*  Compilador  : Netbeans IDE 8.2
:*  Descripci�n : En esta clase se ingresan valores de prueba con resultados comprobados 
:*                para comprobar que el código del proceso está bien formulado.       
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  25/09/2020 Rafael       Se creó la clase de prueba y se agregaron los valores para testear. 
:*  28/09/2020 Rafael       Se modificaron valores de prueba incorrectos
:*------------------------------------------------------------------------------------------*/
package pruebasmatematica;

import matematica.Matematica;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Jesus
 */
public class MatematicaTest {
    
    public MatematicaTest() {
    }
    @BeforeClass
    public static void setUpClass() {
    }
    @AfterClass
    public static void tearDownClass() {
    }
    @Before
    public void setUp() {
    }
    @After
    public void tearDown() {
    }
//-------------------------------------------------------------------------------------------
    @Test
//Código de prueba  para obtener un factorial a partir de un número n.
    public void factorialTest(){
        assertEquals ( "Factorial ( 0 )", 1 , Matematica.factorial ( 0 ) );
        assertEquals ( "Factorial ( 1 )", 1 , Matematica.factorial ( 1 ) );
        assertEquals ( "Factorial ( 5 )", 120 , Matematica.factorial ( 5 ) );
        assertEquals ( "Factorial ( 17 )", 355687428096000L , Matematica.factorial ( 17 ) );
    }
//---------------------------------------------------------------------------------------------
    @Test
//Código de prueba  para obtener una permutación a partir de un número n y un número x.
    public void permutacionesTest(){
        assertEquals ( "Permutaciones ( 0 , 0)", 1 , Matematica.permutaciones ( 0 , 0 ) );
        assertEquals ( "Permutaciones ( 10 , 5 )", 30240 , Matematica.permutaciones ( 10 , 5 ) );
        assertEquals ( "Permutaciones ( 5 , 5 )", 120 , Matematica.permutaciones ( 5 , 5 ) );
        assertEquals ( "Permutaciones ( 18 , 6  )", 13366080 , Matematica.permutaciones ( 18 , 6 ) );     
    }
//--------------------------------------------------------------------------------------------- 
    @Test
//Código de prueba para obtener una combinación a partir de un número n y un número x.
    public void CombinacionesTest(){
        assertEquals ( "Combinaciones ( 0 , 0 )", 1 , Matematica.combinaciones ( 0 , 0 ) );
        assertEquals ( "Combinaciones ( 10 , 5 )", 252 , Matematica.combinaciones ( 10 , 5 ) );
        assertEquals ( "Combinaciones ( 5 , 5 )", 1 , Matematica.combinaciones ( 5 , 5 ) );
        assertEquals ( "Combinaciones ( 18 , 6 )", 18564 , Matematica.combinaciones ( 18 , 6 ) );
        
    }
//--------------------------------------------------------------------------------------------- 
//Código de prueba para obtener el resultado de la formula general.
    @Test
    public void formulaGeneralTest (){
        String [] raices1 = Matematica.FGReal( 1, 4, -5, 36);
        assertEquals ( "Formula general ( 1, 4, -5 )", "1", raices1 [0]  );
        assertEquals ( "Formula general ( 1, 4, -5 )", "-5", raices1 [1]  );
        
        String [] raices2 = Matematica.FGReal( 1, -8, 16, 0);
        assertEquals ( "Formula general ( 1, -8, 16 )", "4", raices2 [0] );
        assertEquals ( "Formula general ( 1, -8, 16 )", "4", raices2 [1] );
        
        String [] raices3 = Matematica.FGImaginario(1, 2, 5, -16);
        assertEquals ( "Formula general ( 1, 2, 5 )", "( -2 + 4 i ) / 2", raices3 [0] );
        assertEquals ( "Formula general ( 1, 2, 5 )", "( -2 - 4 i ) / 2", raices3 [1] );
        
        String [] raices4 = Matematica.FGImaginario(8, 5, 2, -39);
        assertEquals ( "Formula general ( 8, 5, 2 )", "( -5 + 6,245 i ) / 16", raices4 [0] );
        assertEquals ( "Formula general ( 8, 5, 2 )", "( -5 - 6,245 i ) / 16", raices4 [1] );
        
    }
}
