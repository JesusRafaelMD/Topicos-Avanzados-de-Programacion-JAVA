/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                     Clase para probar datos de conversiones
:*        
:*  Archivo     : ConversionesTest.java
:*  Autor       : Jesús Rafael Medina Dimas     19130547
:*  Fecha       : 06/10/2020
:*  Compilador  : Netbeans IDE 8.2
:*  Descripci�n : En esta clase se encuentran valores de prueba rápida para comprobar
                  los métodos de conversiones.
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  06/10/2020 Rafael        Se creó el proyecto 
:*  07/10/2020 Rafael        Se incluyeron todos los valores de prueba del proyecto

:*------------------------------------------------------------------------------------------*/
package pruebasConversiones;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import u1conversiones.Conversiones;

/**
 *
 * @author Jesus
 */
public class ConversionesTest {
    
    public ConversionesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void CaF (){  
        assertEquals( "Celcius a Farenheit ( -18.3 )" , -0.94 , Conversiones.CaF( -18.3 ), 0.01 );
        assertEquals( "Celcius a Farenheit ( 0 )" , 32 , Conversiones.CaF( 0 ), 0.01 );
        assertEquals( "Celcius a Farenheit ( 27.123 )" , 80.8214 , Conversiones.CaF( 27.123 ), 0.01 );
    }     
    
    @Test
    public void FaC () {
        assertEquals( "Farenheit a Celsius ( 0 )" , -17.7777 , Conversiones.FaC( 0 ), 0.01 );
        assertEquals( "Farenheit a Celsius ( 25.12 )" , -3.8222 , Conversiones.FaC( 25.12 ), 0.01 );
        assertEquals( "Farenheit a Celsius ( 75.181 )" , 23.9894 , Conversiones.FaC( 75.181 ), 0.01 );
        
    }
    
    @Test
    public void lbakg () {
        assertEquals( "Libras a kilogramos ( 1 )" , 0.4535 , Conversiones.lbakg(1), 0.01 );
        assertEquals( "Libras a kilogramos ( 21.48 )" , 9.7431 , Conversiones.lbakg(21.48), 0.01 );
        assertEquals( "Libras a kilogramos ( 40.5 )" , 18.3704 , Conversiones.lbakg(40.5), 0.01 );
    }
    
    @Test
    public void kgalb () {
        assertEquals( "Kilogramos a libras ( 1 )" , 2.2046 , Conversiones.kgalb(1), 0.01 );
        assertEquals( "Kilogramos a libras ( 7.845 )" , 17.2952 , Conversiones.kgalb(7.845), 0.01 );
        assertEquals( "Kilogramos a libras ( 27.45 )" , 60.5168 , Conversiones.kgalb(27.45), 0.01 );
        
    }
    
    @Test
    public void binaDec() {
        assertEquals( "Binario a decimal ( 1111101 )" , "125" , Conversiones.binaDec("1111101") );
        assertEquals( "Binario a decimal ( 1011 )" , "11" , Conversiones.binaDec("1011") );
        assertEquals( "Binario a decimal ( 010 )" , "2" , Conversiones.binaDec("010") );
    }
    
    @Test
    public void decaBin() {
        assertEquals( "Decimal a binario ( 8 )" , "1000" , Conversiones.decaBin( 8 ) );
        assertEquals( "Decimal a binario ( 14 )" , "1110" , Conversiones.decaBin( 14 ) );
        assertEquals( "Decimal a binario ( 72 )" , "1001000" , Conversiones.decaBin( 72 ) );
    }
}
