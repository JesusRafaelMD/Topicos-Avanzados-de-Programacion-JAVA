/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                         Aplicación visual 
:*        
:*  Archivo     : ConversionesFrame.java
:*  Autor       : Jesús Rafael Medina Dimas     19130547
:*  Fecha       : 06/10/2020
:*  Compilador  : Netbeans IDE 8.2
:*  Descripci�n : En esta clase se encuentran los elementos visuales de la aplicación.    
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  06/10/2020 Rafael        Se creó el proyecto 
:*  07/10/2020 Rafael        Se añaadieron elementos visuales y el método ejecutar()
:*  08/10/2020 Rafael       Se codificó en su totalidad el codigo logico del boton calcular,
                            además de los eventos del ComboBox .  Se añadió
                            el uso del  df.format para redondear valores
                            en los métodos de grados

:*------------------------------------------------------------------------------------------*/
package u1conversiones;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;


public class ConversionesFrame extends javax.swing.JFrame {

    DecimalFormat df = new DecimalFormat( "#.##");
    
    public ConversionesFrame() {
        
        initComponents();
        jlblTipo.setText( " °C " );
        jlblConvertir.setText( " a °F ");
        
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jbtnAcercaDe = new javax.swing.JButton();
        jcbConvertir = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jtxfTipo = new javax.swing.JTextField();
        jlblTipo = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jlblResultado = new javax.swing.JLabel();
        jbtnConvertir = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jlblConvertir = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jbtnAcercaDe.setText("?");
        jbtnAcercaDe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAcercaDeActionPerformed(evt);
            }
        });

        jcbConvertir.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Centigrado", "Fahrenheit", "Libras", "Kilogramos", "Metros", "Yardas", "Decimal", "Binario" }));
        jcbConvertir.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jcbConvertirItemStateChanged(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Datos"));

        jLabel1.setText("Valor");

        jlblTipo.setText("lb");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxfTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblTipo)
                .addContainerGap(46, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jtxfTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblTipo))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Conversión"));

        jLabel2.setText("Resultado");

        jlblResultado.setBackground(new java.awt.Color(255, 255, 255));
        jlblResultado.setOpaque(true);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblResultado, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jlblResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(126, Short.MAX_VALUE))
        );

        jbtnConvertir.setText("Convertir");
        jbtnConvertir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnConvertirActionPerformed(evt);
            }
        });

        jLabel4.setText("Convertir");

        jlblConvertir.setText("a ___________");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jbtnAcercaDe, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addComponent(jbtnConvertir)
                                .addGap(27, 27, 27))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(27, 27, 27)
                                .addComponent(jcbConvertir, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jlblConvertir)))))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jcbConvertir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(jlblConvertir))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(jbtnConvertir)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jbtnAcercaDe)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnAcercaDeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAcercaDeActionPerformed
        //Se imprime en un cuadro de dialogo la información del alumno

        JOptionPane.showMessageDialog(
            this,
            "TECNOLOGICO NACIONAL DE MEXICO \n" +
            "Instituto tecnologico de la laguna \n" +
            "ISC \t Topicos Avanzados de Programación \n\n" +
            "ConversionesApp v1.0 \n\n" +
            "Desarrollado por: \n "+
            "Jesús Rafael Medina Dimas 19130547 \n\n"+
            "(C) Derechos reservados 2020" ,
            "Acerca de",
            JOptionPane.INFORMATION_MESSAGE,
            Imagenes.escalarImagen(new javax.swing .ImageIcon(getClass() .getResource( "/iconos/itl.png" ) ),
                150,
                150 ) );
    }//GEN-LAST:event_jbtnAcercaDeActionPerformed

    private void jbtnConvertirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnConvertirActionPerformed

        double t = 0;
        String b = "";
        try{
            if (jcbConvertir.getSelectedIndex() == 7) {
                b = jtxfTipo.getText ();
            } else{
                t = Double.parseDouble( jtxfTipo.getText () );
            }
            
            
        } catch ( NumberFormatException ex ){

            JOptionPane.showMessageDialog( this,
                "Valor de n debe ser un valor númerico.",
                "error",
                JOptionPane.ERROR_MESSAGE );
            jtxfTipo.requestFocus();
            return;

        }
        
        switch ( jcbConvertir.getSelectedIndex() ){
            case 0:
                jlblResultado.setText (  df.format ( Conversiones.CaF ( t ) )  + "°F" );
                jlblTipo.setText( " °C " );
                break;
                
            case 1:
                jlblResultado.setText ( df.format (Conversiones.FaC ( t ) )  + "°C" );
                jlblTipo.setText( " °F " );
                break;
                
            case 2:
                jlblResultado.setText ( df.format ( Conversiones.lbakg ( t ) )  + "kg" );
                jlblTipo.setText( " lb " );
                break;
                
            case 3:
                jlblResultado.setText ( df.format ( Conversiones.kgalb ( t ) ) + "lb" );
                jlblTipo.setText( " kg " );
                break;
                
            case 4:
                jlblResultado.setText ( df.format ( Conversiones.mayd ( t ) )   + "yd" );
                jlblTipo.setText( " m " );
                break;
                
            case 5:
                jlblResultado.setText ( df.format ( Conversiones.ydam ( t ) )  + "m" );
                jlblTipo.setText( " yd " );
                break;
                
            case 6:
                
                jlblResultado.setText ( Conversiones.decaBin ( (int)t ) + "" );
                jlblTipo.setText( "  " );
                break;
                
            case 7:
                jlblResultado.setText("");
                jlblResultado.setText ( Conversiones.binaDec ( b ) );
                jlblTipo.setText( "" );
                break;
                
            default:
                jlblResultado.setText ( ( Math.round ( Conversiones.CaF ( t ) ) * 1e2 / 1e2 ) + "°F" );
                jlblTipo.setText( " °C " );
                break;
                
        }
        
        
    }//GEN-LAST:event_jbtnConvertirActionPerformed

    private void jcbConvertirItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jcbConvertirItemStateChanged
        jtxfTipo.setText( "" );
        jlblResultado.setText( "" );

                switch ( jcbConvertir.getSelectedIndex () ){
            case 0:
                jlblTipo.setText( " °C " );
                jlblConvertir.setText( " a °F ");
                break;
                
            case 1:
                jlblTipo.setText( " °F " );
                jlblConvertir.setText( " a °C ");
                break;
                
            case 2:
                jlblTipo.setText( " lb " );
                jlblConvertir.setText( " a kg ");
                break;
                
            case 3:
                jlblTipo.setText( " kg " );
                jlblConvertir.setText( " a lb ");
                break;
                
            case 4:
                jlblTipo.setText( " m " );
                jlblConvertir.setText( " a yd ");
                break;
                
            case 5:
                jlblTipo.setText( " yd " );
                jlblConvertir.setText( " a m ");
                break;
                
            case 6:
                jlblTipo.setText( "  " );
                jlblConvertir.setText( " a binario  ");
                break;
                
            case 7:
                jlblTipo.setText( "  " );
                jlblConvertir.setText( " a decimal ");
                break;
                
            default:
                jlblTipo.setText( " °C " );
                jlblConvertir.setText( " a °F ");
                break;
                
        }
        
    }//GEN-LAST:event_jcbConvertirItemStateChanged
 
    public static void ejecutar (){
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConversionesFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConversionesFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConversionesFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConversionesFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConversionesFrame().setVisible(true);
            }
        });
    }
    public static void main(String args[]) {
        ejecutar ();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JButton jbtnAcercaDe;
    private javax.swing.JButton jbtnConvertir;
    private javax.swing.JComboBox<String> jcbConvertir;
    private javax.swing.JLabel jlblConvertir;
    private javax.swing.JLabel jlblResultado;
    private javax.swing.JLabel jlblTipo;
    private javax.swing.JTextField jtxfTipo;
    // End of variables declaration//GEN-END:variables
}
