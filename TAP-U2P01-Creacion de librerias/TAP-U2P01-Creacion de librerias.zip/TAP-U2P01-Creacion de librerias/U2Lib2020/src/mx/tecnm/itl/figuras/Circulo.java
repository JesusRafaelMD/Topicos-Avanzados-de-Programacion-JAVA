/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                       Clase para crear un circulo
:*        
:*  Archivo     : Circulo.java
:*  Autor       : Jesús Rafael Medina Dimas  19130547
:*  Fecha       : 16/10/2020
:*  Compilador  : NetBeans IDE 8.2
:*  Descripci�n : Clase para crear un circulo, con un atributo de radio, y a partir de 
                  este calcular el diametro, el perimetro, el area y la circunferencia. 
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  16/10/2020  Rafael               Se creó la clase y se codificaron los métodos.
:*  18/10/2020  Rafael               Se modificó el prologo de la aplicación.
:*------------------------------------------------------------------------------------------*/
package mx.tecnm.itl.figuras;

public class Circulo extends Figura {

    private double radio;
    
    //-----------------------------------------------------------------------------------------------
    //Constructor por default de un circulo
    public Circulo () {
        radio = 0;
    }

    //-----------------------------------------------------------------------------------------------
    //Constructor de un circulo donde se indica el valor del radio
    public Circulo ( double radio ) {
        this.radio = radio;
    }

    //-----------------------------------------------------------------------------------------------
    //Método para obtener el diametro del circulo
    public double diametro () {
        return 2 * radio;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para calcular la circunferencia del circulo
    public double circunferencia () {
        return Math.PI * diametro ();
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para obtener el valor del perimetro de la figura
    @Override
    public double perimetro () {
        return circunferencia ();
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para obtener el valor del area de la figura
    @Override
    public double area () {
        return Math.PI * Math.pow ( radio , 2 );
    }
    
     //-----------------------------------------------------------------------------------------------
    //Método para representar la figura en una cadena de tipo String
    @Override
    public String toString () {
        return "Circulo de radio " + radio;
    }
    
    //-----------------------------------------------------------------------------------------------
    public double getRadio () {
        return radio;
    }

    //-----------------------------------------------------------------------------------------------
    public void setRadio ( double radio ) {
        this.radio = radio;
    }

}
