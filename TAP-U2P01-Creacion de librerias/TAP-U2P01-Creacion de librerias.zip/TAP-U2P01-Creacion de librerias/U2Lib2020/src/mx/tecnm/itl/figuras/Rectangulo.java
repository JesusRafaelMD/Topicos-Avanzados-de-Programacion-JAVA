/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                      Clase para crear una figura rectangulo
:*        
:*  Archivo     : Rectangulo.java
:*  Autor       : Jesús Rafael Medina Dimas  19130547
:*  Fecha       : 16/10/2020
:*  Compilador  : NetBeans IDE 8.2
:*  Descripci�n : Clase para crear rectangulo a partir de los atributos de ancho y largo. 
                  Además se codifican los métodos para obtener la diagonal, el perimetro
                  y el area. 
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  16/10/2020  Rafael               Se creó la clase y se codificaron los métodos.
:*  18/10/2020  Rafael               Se modificó el prologo de la aplicación.
:*------------------------------------------------------------------------------------------*/
package mx.tecnm.itl.figuras;

public class Rectangulo extends Figura {

    private double ancho;
    private double largo;
    
    //-----------------------------------------------------------------------------------------------
    //Constructor por default de un Rectangulo
    public Rectangulo () {
        ancho = 0;
        largo = 0;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Constructor de un rectangulo donde se indica el valor del ancho y del largo
    public Rectangulo ( double ancho, double largo ) {
        this.ancho = ancho;
        this.largo = largo;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para calcular el valor de la diagonal del rectangulo
    public double diagonal () {
        return Math.sqrt ( Math.pow ( ancho, 2 ) + Math.pow ( largo, 2 ) );
    } 
    
    //-----------------------------------------------------------------------------------------------
    //Método para obtener el valor del perimetro de la figura
    @Override
    public double perimetro () {
        return 2 * largo + 2 * ancho;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para obtener el valor del area de la figura
    @Override
    public double area () {
        return ancho * largo;
    }
        
    //-----------------------------------------------------------------------------------------------
    //Método para representar la figura en una cadena de tipo String
    @Override
    public String toString () {
        return "Rectangulo de ancho = " + ancho + ", y de largo = " + largo;
    }
    
    //-----------------------------------------------------------------------------------------------    
    public double getAncho () {
        return ancho;
    }
    
    //-----------------------------------------------------------------------------------------------
    public void setAncho ( double ancho ) {
        this.ancho = ancho;
    }
    
    //-----------------------------------------------------------------------------------------------
    public double getLargo () {
        return this.largo;
    }
    
    //-----------------------------------------------------------------------------------------------
    public void setLargo ( double largo ) {
        this.largo = largo;
    }

}
