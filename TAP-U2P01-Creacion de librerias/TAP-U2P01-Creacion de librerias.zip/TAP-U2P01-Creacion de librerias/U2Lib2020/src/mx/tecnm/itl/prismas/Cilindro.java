/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                       descripcion breve de la clase (centrado)
:*        
:*  Archivo     : Cilindro.java
:*  Autor       : Jesús Rafael Medina Dimas  19130547
:*  Fecha       : 16/10/2020
:*  Compilador  : NetBeans IDE 8.2
:*  Descripci�n : Clase para crear un cilindro, con atributos de radio y altura, y a partir
                  de ellos crear circulos que representen su base inferior y su base superior,
                  y un rectangulo que represente su cuerpo. Además se incluyen métodos para
                  calcular el area de la base, el area del cuerpo, el area total y el 
                  volumen.
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  16/10/2020  Rafael       Se creó la clase y se codificaron los métodos.
:*  18/10/2020  Rafael       Se modificó el prologo de la aplicación.
:*------------------------------------------------------------------------------------------*/
package mx.tecnm.itl.prismas;

import mx.tecnm.itl.figuras.Circulo;
import mx.tecnm.itl.figuras.Rectangulo;

public class Cilindro extends Prisma {
	private double radio;
	private double altura;
        
        //Composición del cilindro
        
	private Circulo baseInferior;
        private Circulo baseSuperior;
	public Rectangulo cuerpo;

        //Constructor por default de un cilindro
	public Cilindro () {
		radio = 0;
                altura = 0;
                crearPrisma ();
	}

        //-----------------------------------------------------------------------------------------------
        //Constructor de un cilindro, introduciendo valores de radio y altura
	public Cilindro ( double radio, double altura ) {
            this.radio = radio;
            this.altura = altura;
            crearPrisma ();
	}
        
        //-----------------------------------------------------------------------------------------------
        //Método para crear el prisma a partir de las figuras necesarias
        public void crearPrisma () {
        baseInferior = new Circulo ( radio );
        baseSuperior = new Circulo ( radio );
        cuerpo       = new Rectangulo ( baseInferior.circunferencia(), altura );
        }

	//-----------------------------------------------------------------------------------------------
        //Método para obtener el valor del area de la base del prisma
        @Override 
	public double areaBase () {
            return baseInferior.area ();
	}

        //-----------------------------------------------------------------------------------------------
        //Método para calcular el area lateral del prisma
        @Override 
	public double areaLateral () {
            return cuerpo.area ();
                
	}

        //-----------------------------------------------------------------------------------------------
        //Método para calcular el area total del prisma
        @Override 
	public double areaTotal () {
            return 2 * areaBase () + areaLateral ();
	}

        //-----------------------------------------------------------------------------------------------
        //Método para calcular el volumen del prisma
        @Override 
	public double volumen () {
            return areaBase () * altura;
	}
        
        //-----------------------------------------------------------------------------------------------
        //Método para obtener una cadena de tipo String que represente los datos del prisma.
        @Override
        public String toString () {
		return "Cilindro de radio = " + radio + ", altura = " + altura ;
	}
        
        //---------------------------------------------------------------------------------------
	public double getRadio () {
		return this.radio;
	}

        //-----------------------------------------------------------------------------------------------
	public void setRadio ( double Radio ) {
		this.radio = Radio;
                crearPrisma ();
	}

        //-----------------------------------------------------------------------------------------------
	public double getAltura () {
		return this.altura;
	}

        //-----------------------------------------------------------------------------------------------
	public void setAltura ( double Altura ) {
		this.altura = Altura;
                crearPrisma ();
	}

}