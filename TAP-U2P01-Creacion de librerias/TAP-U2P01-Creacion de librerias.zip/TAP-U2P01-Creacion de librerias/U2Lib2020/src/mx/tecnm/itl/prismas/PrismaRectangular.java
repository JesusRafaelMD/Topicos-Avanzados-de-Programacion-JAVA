/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                      Clase para crear un prisma rectangular
:*        
:*  Archivo     : PrismaRectangular.java
:*  Autor       : Jesús Rafael Medina Dimas  19130547
:*  Fecha       : 16/10/2020
:*  Compilador  : NetBeans IDE 8.2
:*  Descripci�n : Clase para crear un prisma rectangular, con atributos de ancho, largo y altura
                  y a partir de ellos crear rectangulos que representen su base, sus dos caras
                  laterales. 
                  Además se incluyen métodos para calcular el area de la base, el area 
                  del cuerpo, el area total y el volumen.
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  16/10/2020  Rafael               Se creó la clase y se codificaron los métodos.
:*  18/10/2020  Rafael               Se modificó el prologo de la aplicación.
:*------------------------------------------------------------------------------------------*/

package mx.tecnm.itl.prismas;

import mx.tecnm.itl.figuras.Rectangulo;

public class PrismaRectangular extends Prisma {
	private double ancho;
	private double largo;
	private double altura;
	//Composicion del prisma
        private Rectangulo base;
        private Rectangulo caraLateral1;
        private Rectangulo caraLateral2;

        //-----------------------------------------------------------------------------------------------
        //Constructor por default de un prisma rectangular
	public PrismaRectangular () {
		ancho = 0;
                largo = 0;
                altura = 0;
	}

        //-----------------------------------------------------------------------------------------------
        //Constructor de un prisma rectangular, introduciendo valores de ancho, largo y altura. 
	public PrismaRectangular ( double ancho, double largo, double altura ) {
		this.ancho = ancho;
                this.largo = largo;
                this.altura = altura;
                crearPrisma ();
	}
        
        //-----------------------------------------------------------------------------------------------
        //Método para crear el prisma a partir de las figuras necesarias
        public void crearPrisma () {
            base =         new Rectangulo ( ancho , largo );
            caraLateral1 = new Rectangulo ( ancho, altura );
            caraLateral2 = new Rectangulo ( largo, altura );
        }
        
        //-----------------------------------------------------------------------------------------------
        //Método para obtener el valor del area de la base del prisma
        @Override
	public double areaBase () {
		return ancho * largo;
	}

        //-----------------------------------------------------------------------------------------------
        //Método para calcular el area lateral del prisma
        @Override
	public double areaLateral () {
		return ( 2 * largo * altura ) + ( 2 * ancho * altura );
	}

        //-----------------------------------------------------------------------------------------------
        //Método para calcular el area total del prisma
        @Override
	public double areaTotal () {
		return 2 * areaBase () + areaLateral ();
	}

        //-----------------------------------------------------------------------------------------------
        //Método para calcular el volumen del prisma
        @Override
	public double volumen () {
		return areaBase () * altura;
	}
        
        //-----------------------------------------------------------------------------------------------
        //Método para obtener una cadena de tipo String que represente los datos del prisma.
        @Override
	public String toString () {
		return "Rectangulo de ancho = " + ancho + ", largo = " + largo + " y altura = " + altura;
	}

        //-----------------------------------------------------------------------------------------------
	public double getAncho () {
		return this.ancho;
	}

        //-----------------------------------------------------------------------------------------------
	public void setAncho ( double ancho ) {
		this.ancho = ancho;
	}

        //-----------------------------------------------------------------------------------------------
	public double getLargo () {
		return this.largo;
	}

        //-----------------------------------------------------------------------------------------------
	public void setLargo ( double largo ) {
		this.largo = largo;
	}

        //-----------------------------------------------------------------------------------------------
	public double getAltura () {
		return this.altura;
	}

        //-----------------------------------------------------------------------------------------------
	public void setAltura ( double altura ) {
		this.altura = altura;
	}

}