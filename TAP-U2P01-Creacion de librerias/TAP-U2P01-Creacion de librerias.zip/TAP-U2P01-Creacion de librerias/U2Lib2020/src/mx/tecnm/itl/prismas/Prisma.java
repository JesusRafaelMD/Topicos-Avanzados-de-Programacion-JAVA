/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                    Clase abstracta para crear un prisma
:*        
:*  Archivo     : Prisma.java
:*  Autor       : Jesús Rafael Medina Dimas  19130547
:*  Fecha       : 16/10/2020
:*  Compilador  : NetBeans IDE 8.2
:*  Descripci�n : Clase abstracta para declarar los métodos del area de la base, 
                  el area lateral, el area total y el volumen del prisma.
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  16/10/2020  Rafael               Se creó la clase y se codificaron los métodos.
:*  18/10/2020  Rafael               Se modificó el prologo de la aplicación.
:*------------------------------------------------------------------------------------------*/
package mx.tecnm.itl.prismas;

public abstract class Prisma {

    //Declaración de los métodos abstractos para calcular el area de la base, el area lateral, 
    //el area total y el volumen del prisma. 
	public abstract double areaBase ();

	public abstract double areaLateral ();

	public abstract double areaTotal ();

	public abstract double volumen ();
}