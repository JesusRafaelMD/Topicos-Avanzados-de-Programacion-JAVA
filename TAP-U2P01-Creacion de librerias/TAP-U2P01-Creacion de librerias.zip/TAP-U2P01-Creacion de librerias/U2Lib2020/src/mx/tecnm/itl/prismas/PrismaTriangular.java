/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                      Clase para crear un prisma rectangular
:*        
:*  Archivo     : PrismaTriangular.java
:*  Autor       : Jesús Rafael Medina Dimas  19130547
:*  Fecha       : 16/10/2020
:*  Compilador  : NetBeans IDE 8.2
:*  Descripci�n : Clase para crear un prisma triangular, con atributos de base, altura de
                  la base y altura del prisma, además de crear un triangulo rectangulo
                  que represente su base, y dos rectangulos que representen sus dos lados.
                  Además se incluyen métodos para calcular el area de la base, el area 
                  del cuerpo, el area total y el volumen.
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  16/10/2020  Rafael               Se creó la clase y se codificaron los métodos.
:*  18/10/2020  Rafael               Se modificó el prologo de la aplicación.
:*------------------------------------------------------------------------------------------*/

package mx.tecnm.itl.prismas;

import mx.tecnm.itl.figuras.Rectangulo;
import mx.tecnm.itl.figuras.TrianguloRect;

public class PrismaTriangular extends Prisma {

    private double base;
    private double alturaBase;
    private double alturaPrisma;
    
    //Composición del prisma
    private TrianguloRect TBase;
    private Rectangulo RLado1;
    private Rectangulo RLado2;
    //-----------------------------------------------------------------------------------------------
    //Constructor por default de un prisma triangular.
    public PrismaTriangular () {
        base = 0;
        alturaBase = 0;
        alturaPrisma = 0;
    }
    //-----------------------------------------------------------------------------------------------
    //Constructor de un prisma triangular, introduciendo valores de base, altura de la base
    //y altura del prisma. 
    public PrismaTriangular ( double base, double alturaBase, double alturaPrisma ) {
        this.base = base;
        this.alturaBase = alturaBase;
        this.alturaPrisma = alturaPrisma;
        crearPrisma ();
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para crear el prisma a partir de las figuras necesarias
    public void crearPrisma () {
        TBase = new TrianguloRect( base , alturaBase );
        RLado1 = new Rectangulo ( base, alturaPrisma );
        RLado2 = new Rectangulo ( TBase.hipotenusa() , alturaPrisma );
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para obtener el valor del area de la base del prisma
    @Override
    public double areaBase () {
        return TBase.area ();
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para calcular el area lateral del prisma
    @Override
    public double areaLateral () {
        return RLado1.area ()  + RLado2.area () * 2;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para calcular el area total del prisma
    @Override
    public double areaTotal () {
        return areaLateral () + areaBase () * 2;
    }
    //-----------------------------------------------------------------------------------------------
    //Método para calcular el volumen del prisma
    @Override
    public double volumen () {
        return areaBase () * alturaPrisma;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para obtener una cadena de tipo String que represente los datos del prisma.
    @Override
    public String toString () {
        return "Triangulo de base = " + base + ", altura de la base = " + alturaBase +
                                            ", y altura del prisma = " + alturaPrisma;
    }
    
    //-----------------------------------------------------------------------------------------------
    public double getBase () {
        return this.base;
    }
    //-----------------------------------------------------------------------------------------------
    public void setBase ( double base ) {
        this.base = base;
    }
    //-----------------------------------------------------------------------------------------------
    public double getAlturaBase () {
        return this.alturaBase;
    }
    //-----------------------------------------------------------------------------------------------
    public void setAlturaBase ( double alturaBase ) {
        this.alturaBase = alturaBase;
    }
    //-----------------------------------------------------------------------------------------------
    public double getAlturaPrisma () {
        return this.alturaPrisma;
    }
    //-----------------------------------------------------------------------------------------------
    public void setAlturaPrisma ( double alturaPrisma ) {
        this.alturaPrisma = alturaPrisma;
    }
}
