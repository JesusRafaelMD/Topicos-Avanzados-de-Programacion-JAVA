/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                       descripcion breve de la clase (centrado)
:*        
:*  Archivo     : Figura.java
:*  Autor       : Jesús Rafael Medina Dimas  19130547
:*  Fecha       : 16/10/2020
:*  Compilador  : NetBeans IDE 8.2
:*  Descripci�n : Clase abstracta para declarar los métodos abstractos de perimetro
                  y area.
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  16/10/2020  Rafael               Se creó la clase y se codificaron los métodos.
:*  18/10/2020  Rafael               Se modificó el prologo de la aplicación.
:*------------------------------------------------------------------------------------------*/
package mx.tecnm.itl.figuras;
public abstract class Figura {
    
    //Declaración de los métodos abstractos perimetro y area, para las figuras
	public abstract double perimetro ();
	public abstract double area ();
	

}