/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                       TOPICOS AVANZADOS DE PROGRAMACION "B"
:*
:*                   SEMESTRE: AGO-DIC/2020    HORA: 17-18 HRS
:*
:*                     Clase para crear un triangulo rectangulo
:*        
:*  Archivo     : TrianguloRect.java
:*  Autor       : Jesús Rafael Medina Dimas     19130547
:*  Fecha       : 16/10/2020
:*  Compilador  : Netbeans IDE 8.2
:*  Descripci�n : Clase para crear una figura de triangulo rectangulo a partir de sus 
                  atributos de base y altura.
                  Además de métodos para calcular la hipotenusa, el perimetro y el area.
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*========================================================================================== 
:*  16/10/2020 Rafael       Se creó la clase
:*  18/10/2020 Rafael       Se modificó el prologo de la clase
:*------------------------------------------------------------------------------------------*/
package mx.tecnm.itl.figuras;

public class TrianguloRect extends Figura {

    private double base;
    private double altura;
    
    //-----------------------------------------------------------------------------------------------
    //Constructor por default de un triangulo rectangulo
    public TrianguloRect () {
        base = 0;
        altura = 0;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Constructor de un triangulo rectangulo, donde se indica el valor de la base y de la altura
    public TrianguloRect ( double base, double altura ) {
        this.base = base;
        this.altura = altura;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para calcular la hipotenusa del triangulo rectangulo
    public double hipotenusa () {
        return Math.sqrt ( Math.pow( base, 2 ) + Math.pow ( altura, 2 ) );
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para representar la figura en una cadena de tipo String
    @Override
    public String toString () {
        return "Triangulo rectangulo de base = " + base + ", altura = " + altura;
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para obtener el valor del perimetro de la figura
    @Override
    public double perimetro () {
        return base + altura + hipotenusa();
    }
    
    //-----------------------------------------------------------------------------------------------
    //Método para obtener el valor del area de la figura
    @Override
    public double area () {
        return base * altura / 2;
    }
    
    //-----------------------------------------------------------------------------------------------
    public double getBase () {
        return this.base;
    }
    
    //-----------------------------------------------------------------------------------------------
    public void setBase ( double base ) {
        this.base = base;
    }
    
    //-----------------------------------------------------------------------------------------------
    public double getAltura () {
        return this.altura;
    }
    
    //-----------------------------------------------------------------------------------------------
    public void setAltura ( double altura ) {
        this.altura = altura;
    }

}
